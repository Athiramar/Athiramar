INSERT INTO `manufacturers` VALUES(NULL, 'HP');
INSERT INTO `manufacturers` VALUES(NULL, 'Epson');
INSERT INTO `manufacturers` VALUES(NULL, 'Kyocera');
INSERT INTO `manufacturers` VALUES(NULL, 'Samsung');
INSERT INTO `manufacturers` VALUES(NULL, 'Brother');
INSERT INTO `manufacturers` VALUES(NULL, 'OKI');
INSERT INTO `manufacturers` VALUES(NULL, 'Canon');
INSERT INTO `manufacturers` VALUES(NULL, 'Kodak');
