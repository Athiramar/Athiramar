# Changelog

### 1.4.0 - 19.02.2013
* Fix model name character length
* Update to config methods (please see UPGRADE for instructions)
* Add grand total for consumable stock
* Add "Save and add new" feature
* Add printer count to models list
* Add printer count to consumables
* Add chargeback feature
* Add consumable type feature

### 1.3.0 - 22.08.2013
* Add Purchase Cost and Purchase Date fields to printers.

### 1.2.1 - 22.08.2013
* Fix for issue where costs on consumables and reports would hold max. value of 99.99.

### 1.2.0 - 18.08.2013
* Add cost feature to consumables and reports

### 1.1.0 - 03.08.2013
* Update Flourish library
* Add search functionality for printer list on dashboard
* Add ability to select multiple consumables for installation

### 1.0.1 - 07.10.2010
* Created