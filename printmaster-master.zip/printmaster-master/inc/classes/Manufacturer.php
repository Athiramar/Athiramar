<?php
class Manufacturer extends fActiveRecord{
    
	
	protected function configure(){
    }
	
	
}