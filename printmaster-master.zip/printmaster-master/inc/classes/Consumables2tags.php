<?php
class Consumables2tags extends fActiveRecord {


	protected function configure()
	{
	}


}