<?php
class Event extends fActiveRecord{
    
	
	protected function configure(){
    }
	
	
}