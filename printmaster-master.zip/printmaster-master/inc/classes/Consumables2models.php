<?php
class Consumables2models extends fActiveRecord{
    
	
	protected function configure(){
    }
	
	
}