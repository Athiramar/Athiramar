<?php 
session_start();

// Database connection
$db_host = '127.0.0.1';  // Use 127.0.0.1 instead of localhost
$db_user = 'root';       
$db_pass = 'root';       
$db_name = 'Project';   
$db_port = 3306;        

// Connect to MySQL database
$db = new mysqli($db_host, $db_user, $db_pass, $db_name, $db_port);

// Check connection
if ($db->connect_error) {
    die("Database connection failed: " . $db->connect_error);
}

// Initialize variables
$username = "";
$email = "";
$errors = [];

// REGISTER USER
if (isset($_POST['reg_user'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password_1 = $_POST['password_1'];
    $password_2 = $_POST['password_2'];

    // Validate inputs
    if (empty($username)) array_push($errors, "Username is required");
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) array_push($errors, "Valid email is required");
    if (empty($password_1)) array_push($errors, "Password is required");
    if ($password_1 !== $password_2) array_push($errors, "Passwords do not match");

    // Check if user exists
    $stmt = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    if (!$stmt) {
        die("SQL Error: " . $db->error);
    }
    $stmt->bind_param("ss", $username, $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        array_push($errors, "Username or Email already exists");
    }
    $stmt->close();

    // Register user
    if (empty($errors)) {
        $password = password_hash($password_1, PASSWORD_BCRYPT);
        $stmt = $db->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        if (!$stmt) {
            die("SQL Error: " . $db->error);
        }
        $stmt->bind_param("sss", $username, $email, $password);
        $stmt->execute();
        $stmt->close();

        $_SESSION['username'] = $username;
        $_SESSION['success'] = "You are now logged in";
        header('location: index.php');
        exit();
    }
}

// LOGIN USER
if (isset($_POST['login_user'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (empty($username)) array_push($errors, "Username is required");
    if (empty($password)) array_push($errors, "Password is required");

    if (empty($errors)) {
        $stmt = $db->prepare("SELECT id, password FROM users WHERE username = ?");
        if (!$stmt) {
            die("SQL Error: " . $db->error);
        }
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows == 1) {
            $stmt->bind_result($user_id, $hashed_password);
            $stmt->fetch();

            if (password_verify($password, $hashed_password)) {
                $_SESSION['username'] = $username;
                $_SESSION['success'] = "You are now logged in";
                header('location: index.php');
                exit();
            } else {
                array_push($errors, "Wrong username/password combination");
            }
        } else {
            array_push($errors, "Wrong username/password combination");
        }
        $stmt->close();
    }
}
?>

