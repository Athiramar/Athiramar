<?php
function AddCartSucessMsg()
{
    echo '';
}
?>