<?php
// Include header
include 'header.php';

// Get dashboard statistics
$totalProducts = 0;
$totalOrders = 0;
$totalCustomers = 0;
$totalRevenue = 0;

// Query to get total products
$productsQuery = "SELECT COUNT(*) as total FROM products";
$productsResult = getRecord($productsQuery);
if ($productsResult) {
    $totalProducts = $productsResult['total'];
}

// Query to get total orders
$ordersQuery = "SELECT COUNT(*) as total FROM orders";
$ordersResult = getRecord($ordersQuery);
if ($ordersResult) {
    $totalOrders = $ordersResult['total'];
}

// Query to get total customers
$customersQuery = "SELECT COUNT(*) as total FROM users";
$customersResult = getRecord($customersQuery);
if ($customersResult) {
    $totalCustomers = $customersResult['total'];
}

// Query to get total revenue
$revenueQuery = "SELECT SUM(total_price) as total FROM orders";
$revenueResult = getRecord($revenueQuery);
if ($revenueResult) {
    $totalRevenue = $revenueResult['total'] ?? 0;
}

// Get recent orders
$recentOrdersQuery = "SELECT o.id, o.total_price, o.status, o.date, u.name as customer_name 
                      FROM orders o 
                      LEFT JOIN users u ON o.user_id = u.id 
                      ORDER BY o.date DESC LIMIT 5";
$recentOrders = getRecords($recentOrdersQuery);

// Get low stock products
$lowStockQuery = "SELECT id, name, stock FROM products WHERE stock <= 10 ORDER BY stock ASC LIMIT 5";
$lowStockProducts = getRecords($lowStockQuery);
?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
    </ol>
    
    <!-- Dashboard Stats -->
    <div class="row">
        <div class="col-xl-3 col-md-6">
            <div class="card stats-card primary mb-4">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <div class="stats-label">Total Products</div>
                            <div class="stats-number"><?php echo $totalProducts; ?></div>
                        </div>
                        <div class="col-4 text-end">
                            <i class="fas fa-box fa-2x text-primary"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-primary" href="products.php">View Details</a>
                    <div class="small text-primary"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card stats-card success mb-4">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <div class="stats-label">Total Orders</div>
                            <div class="stats-number"><?php echo $totalOrders; ?></div>
                        </div>
                        <div class="col-4 text-end">
                            <i class="fas fa-shopping-cart fa-2x text-success"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-success" href="orders.php">View Details</a>
                    <div class="small text-success"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card stats-card info mb-4">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <div class="stats-label">Total Customers</div>
                            <div class="stats-number"><?php echo $totalCustomers; ?></div>
                        </div>
                        <div class="col-4 text-end">
                            <i class="fas fa-users fa-2x text-info"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-info" href="users.php">View Details</a>
                    <div class="small text-info"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6">
            <div class="card stats-card warning mb-4">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <div class="stats-label">Total Revenue</div>
                            <div class="stats-number">$<?php echo number_format($totalRevenue, 2); ?></div>
                        </div>
                        <div class="col-4 text-end">
                            <i class="fas fa-dollar-sign fa-2x text-warning"></i>
                        </div>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-warning" href="reports.php">View Details</a>
                    <div class="small text-warning"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Charts Row -->
    <div class="row">
        <div class="col-xl-8">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-chart-line me-1"></i>
                    Monthly Sales
                </div>
                <div class="card-body">
                    <canvas id="salesChart" height="300"></canvas>
                </div>
            </div>
        </div>
        <div class="col-xl-4">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-chart-pie me-1"></i>
                    Products by Category
                </div>
                <div class="card-body">
                    <canvas id="categoryChart" height="300"></canvas>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Tables Row -->
    <div class="row">
        <!-- Recent Orders -->
        <div class="col-xl-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-shopping-cart me-1"></i>
                    Recent Orders
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Customer</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($recentOrders)): ?>
                                <tr>
                                    <td colspan="5" class="text-center">No orders found</td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach ($recentOrders as $order): ?>
                                    <tr>
                                        <td><a href="order_details.php?id=<?php echo $order['id']; ?>">#<?php echo $order['id']; ?></a></td>
                                        <td><?php echo $order['customer_name']; ?></td>
                                        <td>$<?php echo number_format($order['total_price'], 2); ?></td>
                                        <td>
                                            <?php 
                                            $statusClass = '';
                                            switch ($order['status']) {
                                                case 'Pending':
                                                    $statusClass = 'bg-warning';
                                                    break;
                                                case 'Processing':
                                                    $statusClass = 'bg-info';
                                                    break;
                                                case 'Shipped':
                                                    $statusClass = 'bg-primary';
                                                    break;
                                                case 'Completed':
                                                    $statusClass = 'bg-success';
                                                    break;
                                                case 'Cancelled':
                                                    $statusClass = 'bg-danger';
                                                    break;
                                                default:
                                                    $statusClass = 'bg-secondary';
                                            }
                                            ?>
                                            <span class="badge <?php echo $statusClass; ?>"><?php echo $order['status']; ?></span>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($order['date'])); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-end mt-3">
                        <a href="orders.php" class="btn btn-sm btn-primary">View All Orders</a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Low Stock Products -->
        <div class="col-xl-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-exclamation-triangle me-1"></i>
                    Low Stock Products
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Product ID</th>
                                    <th>Product Name</th>
                                    <th>Stock</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($lowStockProducts)): ?>
                                <tr>
                                    <td colspan="4" class="text-center">No low stock products found</td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach ($lowStockProducts as $product): ?>
                                    <tr>
                                        <td>#<?php echo $product['id']; ?></td>
                                        <td><?php echo $product['name']; ?></td>
                                        <td>
                                            <span class="badge bg-danger"><?php echo $product['stock']; ?> left</span>
                                        </td>
                                        <td>
                                            <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-primary">Update Stock</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-end mt-3">
                        <a href="stock.php" class="btn btn-sm btn-primary">Manage Inventory</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include 'footer.php';
?>
