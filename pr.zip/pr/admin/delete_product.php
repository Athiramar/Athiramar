<?php
// Include database connection
require_once 'db.php';

// Check if admin is logged in
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Check if product ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: products.php");
    exit();
}

$product_id = (int)$_GET['id'];

// Get product image before deletion to delete the file
$imageQuery = "SELECT image FROM products WHERE id = $product_id";
$product = getRecord($imageQuery);

if ($product) {
    // Delete the image file if it exists
    if (!empty($product['image'])) {
        $imagePath = 'upload/' . $product['image'];
        if (file_exists($imagePath)) {
            unlink($imagePath); // Delete the image file
        }
    }
    
    // Delete the product from database
    $deleteQuery = "DELETE FROM products WHERE id = $product_id";
    $deleteResult = executeQuery($deleteQuery);
    
    if ($deleteResult) {
        // Set success message in session
        $_SESSION['message'] = "Product deleted successfully!";
        $_SESSION['message_type'] = "success";
    } else {
        // Set error message in session
        $_SESSION['message'] = "Failed to delete product. Please try again.";
        $_SESSION['message_type'] = "danger";
    }
} else {
    // Set error message in session
    $_SESSION['message'] = "Product not found.";
    $_SESSION['message_type'] = "danger";
}

// Redirect back to products page
header("Location: products.php");
exit();
?>
