<?php
// Database Connection File
$host = "127.0.0.1";
$username = "root";
$password = "root";
$database = "offset_printing_db";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to ensure proper display of special characters
$conn->set_charset("utf8");

// Function to sanitize input data
function sanitize($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    $data = $conn->real_escape_string($data);
    return $data;
}

// Function to execute queries safely
function executeQuery($sql) {
    global $conn;
    try {
        $result = $conn->query($sql);
        if (!$result) {
            throw new Exception("MySQL Error: " . $conn->error . " SQL: " . $sql);
        }
        return $result;
    } catch (Exception $e) {
        error_log($e->getMessage());
        return false;
    }
}

// Function to get a single record
function getRecord($sql) {
    $result = executeQuery($sql);
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return false;
}

// Function to get multiple records
function getRecords($sql) {
    $result = executeQuery($sql);
    $records = [];
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $records[] = $row;
        }
    }
    return $records;
}

// Example usage with error handling
$sql = "SELECT o.id, o.status FROM your_table o"; // Ensure 'status' column exists
$records = getRecords($sql);
if ($records === false) {
    echo "Failed to retrieve records.";
} else {
    foreach ($records as $record) {
        echo $record['id'] . "\n";
        // Ensure 'status' key exists before accessing it
        if (isset($record['status'])) {
            echo $record['status'] . "\n";
        } else {
            echo "Status column does not exist.\n";
        }
    }
}
?>
