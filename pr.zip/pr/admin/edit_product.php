<?php
// Include header
include 'header.php';

// Check if product ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: products.php");
    exit();
}

$product_id = (int)$_GET['id'];

// Fetch product details
$query = "SELECT * FROM products WHERE id = $product_id";
$product = getRecord($query);

// Check if product exists
if (!$product) {
    header("Location: products.php");
    exit();
}

// Initialize variables
$name = $product['name'];
$category = $product['category'];
$description = $product['description'];
$price = $product['price'];
$stock = $product['stock'];
$current_image = $product['image'];
$error = $success = "";

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = sanitize($_POST['name']);
    $category = sanitize($_POST['category']);
    $description = sanitize($_POST['description']);
    $price = (float)$_POST['price'];
    $stock = (int)$_POST['stock'];
    
    // Validate form data
    if (empty($name) || empty($category) || $price <= 0 || $stock < 0) {
        $error = "Please fill all required fields with valid values";
    } else {
        // Handle image upload if new image is selected
        $image_name = $current_image; // Keep existing image by default
        
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            
            if (in_array($_FILES['image']['type'], $allowed_types)) {
                $image_name = time() . '_' . $_FILES['image']['name'];
                $target_dir = "upload/";
                $target_file = $target_dir . $image_name;
                
                // Create directory if it doesn't exist
                if (!file_exists($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                    // Delete old image if it exists
                    if (!empty($current_image) && file_exists("upload/" . $current_image)) {
                        unlink("upload/" . $current_image);
                    }
                } else {
                    $error = "Failed to upload image";
                }
            } else {
                $error = "Invalid file type. Only JPG, PNG, and GIF files are allowed";
            }
        }
        
        if (empty($error)) {
            // Update product in database
            $sql = "UPDATE products SET 
                    name = '$name', 
                    category = '$category', 
                    description = '$description', 
                    price = $price, 
                    stock = $stock, 
                    image = '$image_name'
                    WHERE id = $product_id";
            
            if (executeQuery($sql)) {
                $success = "Product updated successfully!";
                
                // Refresh product data
                $product = getRecord("SELECT * FROM products WHERE id = $product_id");
                $current_image = $product['image'];
            } else {
                $error = "Failed to update product. Please try again.";
            }
        }
    }
}
?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Edit Product</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="products.php">Products</a></li>
        <li class="breadcrumb-item active">Edit Product</li>
    </ol>
    
    <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <?php if (!empty($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-edit me-1"></i>
            Edit Product Information
        </div>
        <div class="card-body">
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $product_id; ?>" method="POST" enctype="multipart/form-data">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="name" class="form-label">Product Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="category" class="form-label">Category <span class="text-danger">*</span></label>
                            <select class="form-select" id="category" name="category" required>
                                <option value="" disabled>Select Category</option>
                                <option value="Brochures" <?php echo $category == 'Brochures' ? 'selected' : ''; ?>>Brochures</option>
                                <option value="Business Cards" <?php echo $category == 'Business Cards' ? 'selected' : ''; ?>>Business Cards</option>
                                <option value="Flyers" <?php echo $category == 'Flyers' ? 'selected' : ''; ?>>Flyers</option>
                                <option value="Posters" <?php echo $category == 'Posters' ? 'selected' : ''; ?>>Posters</option>
                                <option value="Banners" <?php echo $category == 'Banners' ? 'selected' : ''; ?>>Banners</option>
                                <option value="Labels" <?php echo $category == 'Labels' ? 'selected' : ''; ?>>Labels</option>
                                <option value="Other" <?php echo $category == 'Other' ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="price" class="form-label">Price ($) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="price" name="price" step="0.01" min="0" value="<?php echo $price; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="stock" class="form-label">Stock <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="stock" name="stock" min="0" value="<?php echo $stock; ?>" required>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="5"><?php echo $description; ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="image" class="form-label">Product Image</label>
                            <input type="file" class="form-control" id="product_image" name="image" accept="image/*">
                            <small class="form-text text-muted">Leave empty to keep current image</small>
                            
                            <div class="mt-3">
                                <?php if (!empty($current_image) && file_exists('upload/' . $current_image)): ?>
                                    <p>Current Image:</p>
                                    <img src="upload/<?php echo $current_image; ?>" alt="<?php echo $name; ?>" class="img-thumbnail" style="max-width: 200px; max-height: 200px;">
                                <?php else: ?>
                                    <p>No image currently set</p>
                                <?php endif; ?>
                                
                                <img id="image_preview" src="#" alt="New Image Preview" style="max-width: 200px; max-height: 200px; display: none;">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="d-flex justify-content-between">
                    <a href="products.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Update Product</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
// Include footer
include 'footer.php';
?>
