<?php
// Start session
session_start();

// Redirect to dashboard if logged in, or to login page if not
if (isset($_SESSION['admin_id'])) {
    header("Location: dashboard.php");
} else {
    header("Location: login.php");
}
exit();
?>
