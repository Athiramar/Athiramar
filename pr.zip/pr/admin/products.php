<?php
// Include header
include 'header.php';

// Process delete action if requested
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $product_id = (int)$_GET['id'];
    
    // Get product image before deletion to delete the file
    $imageQuery = "SELECT image FROM products WHERE id = $product_id";
    $product = getRecord($imageQuery);
    
    if ($product && !empty($product['image'])) {
        $imagePath = 'upload/' . $product['image'];
        if (file_exists($imagePath)) {
            unlink($imagePath); // Delete the image file
        }
    }
    
    // Delete the product from database
    $deleteQuery = "DELETE FROM products WHERE id = $product_id";
    $deleteResult = executeQuery($deleteQuery);
    
    if ($deleteResult) {
        $success_message = "Product deleted successfully!";
    } else {
        $error_message = "Failed to delete product. Please try again.";
    }
}

// Get all products
$query = "SELECT p.*, COUNT(o.id) as order_count 
          FROM products p 
          LEFT JOIN order_items oi ON p.id = oi.product_id 
          LEFT JOIN orders o ON oi.order_id = o.id 
          GROUP BY p.id 
          ORDER BY p.id DESC";
$products = getRecords($query);
?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Products</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Products</li>
    </ol>
    
    <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php endif; ?>
    
    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>
    
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div>
                <i class="fas fa-box me-1"></i>
                Product Management
            </div>
            <a href="add_product.php" class="btn btn-primary btn-sm">
                <i class="fas fa-plus"></i> Add New Product
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover datatable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Orders</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($products)): ?>
                            <tr>
                                <td colspan="8" class="text-center">No products found</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($products as $product): ?>
                                <tr>
                                    <td><?php echo $product['id']; ?></td>
                                    <td>
                                        <?php if (!empty($product['image']) && file_exists('upload/' . $product['image'])): ?>
                                            <img src="upload/<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="img-thumbnail" style="max-width: 50px;">
                                        <?php else: ?>
                                            <img src="https://via.placeholder.com/50" alt="No Image" class="img-thumbnail">
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $product['name']; ?></td>
                                    <td><?php echo $product['category']; ?></td>
                                    <td>$<?php echo number_format($product['price'], 2); ?></td>
                                    <td>
                                        <?php if ($product['stock'] <= 10): ?>
                                            <span class="badge bg-danger"><?php echo $product['stock']; ?></span>
                                        <?php elseif ($product['stock'] <= 20): ?>
                                            <span class="badge bg-warning"><?php echo $product['stock']; ?></span>
                                        <?php else: ?>
                                            <?php echo $product['stock']; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $product['order_count']; ?></td>
                                    <td>
                                        <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="products.php?action=delete&id=<?php echo $product['id']; ?>" class="btn btn-sm btn-danger delete-btn">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
include 'footer.php';
?>
