<?php
// Include header
include 'header.php';

// Check if order ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: orders.php");
    exit();
}

$order_id = (int)$_GET['id'];

// Fetch order details
$orderQuery = "SELECT o.*, u.name as customer_name, u.email as customer_email, u.phone as customer_phone, u.address as customer_address 
               FROM orders o 
               LEFT JOIN users u ON o.user_id = u.id 
               WHERE o.id = $order_id";
$order = getRecord($orderQuery);

// Check if order exists
if (!$order) {
    header("Location: orders.php");
    exit();
}

// Fetch order items
$itemsQuery = "SELECT oi.*, p.name as product_name, p.image as product_image 
               FROM order_items oi 
               LEFT JOIN products p ON oi.product_id = p.id 
               WHERE oi.order_id = $order_id";
$orderItems = getRecords($itemsQuery);

// Handle order status update
if (isset($_POST['update_status']) && isset($_POST['status'])) {
    $status = sanitize($_POST['status']);
    
    $updateQuery = "UPDATE orders SET status = '$status' WHERE id = $order_id";
    $updateResult = executeQuery($updateQuery);
    
    if ($updateResult) {
        $success_message = "Order status updated successfully!";
        // Refresh order data
        $order = getRecord($orderQuery);
    } else {
        $error_message = "Failed to update order status. Please try again.";
    }
}

// Format order date
$orderDate = date('F d, Y h:i A', strtotime($order['date']));

// Determine status badge class
$statusClass = '';
switch ($order['status']) {
    case 'Pending':
        $statusClass = 'bg-warning';
        break;
    case 'Processing':
        $statusClass = 'bg-info';
        break;
    case 'Shipped':
        $statusClass = 'bg-primary';
        break;
    case 'Completed':
        $statusClass = 'bg-success';
        break;
    case 'Cancelled':
        $statusClass = 'bg-danger';
        break;
    default:
        $statusClass = 'bg-secondary';
}
?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Order Details</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="orders.php">Orders</a></li>
        <li class="breadcrumb-item active">Order #<?php echo $order_id; ?></li>
    </ol>
    
    <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php endif; ?>
    
    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>
    
    <div class="row">
        <!-- Order Summary -->
        <div class="col-xl-4">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-info-circle me-1"></i>
                    Order Summary
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-3">
                        <h5 class="card-title">Order #<?php echo $order_id; ?></h5>
                        <span class="badge <?php echo $statusClass; ?>"><?php echo $order['status']; ?></span>
                    </div>
                    
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Date:</span>
                            <span><?php echo $orderDate; ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Total Items:</span>
                            <span><?php echo count($orderItems); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Subtotal:</span>
                            <span>$<?php echo number_format($order['total_price'], 2); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Tax:</span>
                            <span>$<?php echo number_format($order['total_price'] * 0.1, 2); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between fw-bold">
                            <span>Total:</span>
                            <span>$<?php echo number_format($order['total_price'] * 1.1, 2); ?></span>
                        </li>
                    </ul>
                    
                    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $order_id; ?>" class="mt-3">
                        <div class="mb-3">
                            <label for="status" class="form-label">Order Status</label>
                            <select class="form-select" id="status" name="status">
                                <option value="Pending" <?php echo ($order['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                <option value="Processing" <?php echo ($order['status'] == 'Processing') ? 'selected' : ''; ?>>Processing</option>
                                <option value="Shipped" <?php echo ($order['status'] == 'Shipped') ? 'selected' : ''; ?>>Shipped</option>
                                <option value="Completed" <?php echo ($order['status'] == 'Completed') ? 'selected' : ''; ?>>Completed</option>
                                <option value="Cancelled" <?php echo ($order['status'] == 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                            </select>
                        </div>
                        <input type="hidden" name="update_status" value="1">
                        <button type="submit" class="btn btn-primary">Update Status</button>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Customer Details -->
        <div class="col-xl-4">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-user me-1"></i>
                    Customer Information
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?php echo $order['customer_name']; ?></h5>
                    
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <i class="fas fa-envelope me-2"></i>
                            <?php echo $order['customer_email']; ?>
                        </li>
                        <li class="list-group-item">
                            <i class="fas fa-phone me-2"></i>
                            <?php echo !empty($order['customer_phone']) ? $order['customer_phone'] : 'N/A'; ?>
                        </li>
                        <li class="list-group-item">
                            <i class="fas fa-map-marker-alt me-2"></i>
                            <?php echo !empty($order['customer_address']) ? nl2br($order['customer_address']) : 'N/A'; ?>
                        </li>
                    </ul>
                    
                    <a href="users.php?id=<?php echo $order['user_id']; ?>" class="btn btn-outline-primary mt-3">
                        <i class="fas fa-user-circle me-1"></i> View Customer Profile
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Shipping Information -->
        <div class="col-xl-4">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-truck me-1"></i>
                    Shipping Information
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <strong>Shipping Address:</strong><br>
                            <?php echo !empty($order['shipping_address']) ? nl2br($order['shipping_address']) : nl2br($order['customer_address']); ?>
                        </li>
                        <li class="list-group-item">
                            <strong>Shipping Method:</strong><br>
                            <?php echo !empty($order['shipping_method']) ? $order['shipping_method'] : 'Standard Shipping'; ?>
                        </li>
                        <?php if ($order['status'] == 'Shipped' || $order['status'] == 'Completed'): ?>
                        <li class="list-group-item">
                            <strong>Tracking Number:</strong><br>
                            <?php echo !empty($order['tracking_number']) ? $order['tracking_number'] : 'Not available'; ?>
                        </li>
                        <?php endif; ?>
                    </ul>
                    
                    <div class="mt-3">
                        <a href="#" class="btn btn-outline-success" onclick="window.print()">
                            <i class="fas fa-print me-1"></i> Print Invoice
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Order Items -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-box-open me-1"></i>
            Order Items
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Product</th>
                            <th>Unit Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($orderItems)): ?>
                            <tr>
                                <td colspan="5" class="text-center">No items found for this order</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($orderItems as $index => $item): ?>
                                <tr>
                                    <td><?php echo $index + 1; ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <?php if (!empty($item['product_image']) && file_exists('upload/' . $item['product_image'])): ?>
                                                <img src="upload/<?php echo $item['product_image']; ?>" alt="<?php echo $item['product_name']; ?>" class="img-thumbnail me-3" style="max-width: 50px;">
                                            <?php else: ?>
                                                <img src="https://via.placeholder.com/50" alt="No Image" class="img-thumbnail me-3">
                                            <?php endif; ?>
                                            <div>
                                                <a href="edit_product.php?id=<?php echo $item['product_id']; ?>"><?php echo $item['product_name']; ?></a>
                                                <small class="d-block text-muted">SKU: PRD-<?php echo $item['product_id']; ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>$<?php echo number_format($item['price'], 2); ?></td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td>$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <div class="text-start mb-4">
        <a href="orders.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Back to Orders
        </a>
    </div>
</div>

<?php
// Include footer
include 'footer.php';
?>
