<?php
// Set your desired password here
$password = "admin123"; // Change this to your preferred password

// Hash the password using PHP's password_hash() function
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Display the hashed password
echo "Hashed Password: " . $hashedPassword;
?>
