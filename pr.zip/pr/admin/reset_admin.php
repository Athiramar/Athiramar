<?php
// Database Configuration
$host = "127.0.0.1";
$username = "root";
$password = "root";
$database = "offset_printing_db";

// Connect to MySQL
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set new admin credentials
$admin_username = "admin";
$admin_password = password_hash("admin123", PASSWORD_DEFAULT); // Using password_hash for secure password storage
$admin_email = "admin@example.com";
$admin_name = "Administrator";

// Delete existing admin user if exists
$delete_sql = "DELETE FROM admin_users WHERE username='admin'";
$conn->query($delete_sql);

// Insert new admin user
$insert_sql = "INSERT INTO admin_users (username, password, email, name) 
               VALUES ('$admin_username', '$admin_password', '$admin_email', '$admin_name')";

if ($conn->query($insert_sql) === TRUE) {
    echo "<h2>Admin Account Reset Successfully</h2>";
    echo "<p>The admin account has been reset with the following credentials:</p>";
    echo "<ul>";
    echo "<li><strong>Username:</strong> admin</li>";
    echo "<li><strong>Password:</strong> admin123</li>";
    echo "</ul>";
    echo "<p><a href='login.php'>Go to Login Page</a></p>";
} else {
    echo "<h2>Error Resetting Admin Account</h2>";
    echo "<p>Error: " . $conn->error . "</p>";
}

// Close connection
$conn->close();
?>
