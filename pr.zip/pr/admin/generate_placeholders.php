            <?php
// Include database connection
require_once 'db.php';

// Ensure upload directory exists
$uploadDir = 'upload/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Generate CSS-based placeholder images
$cssPlaceholders = [
    [
        'name' => 'business_cards_placeholder.html',
        'category' => 'Business Cards',
        'color' => '#4287f5',
        'width' => 500,
        'height' => 300
    ],
    [
        'name' => 'flyers_placeholder.html',
        'category' => 'Flyers',
        'color' => '#2ecc71',
        'width' => 500,
        'height' => 700
    ],
    [
        'name' => 'brochures_placeholder.html',
        'category' => 'Brochures',
        'color' => '#e74c3c',
        'width' => 600,
        'height' => 400
    ],
    [
        'name' => 'posters_placeholder.html',
        'category' => 'Posters',
        'color' => '#f1c40f',
        'width' => 700,
        'height' => 1000
    ],
    [
        'name' => 'banners_placeholder.html',
        'category' => 'Banners',
        'color' => '#9b59b6',
        'width' => 1000,
        'height' => 300
    ]
];

// Create local placeholder HTML files
foreach ($cssPlaceholders as $placeholder) {
    $htmlContent = '<!DOCTYPE html>
    <html>
    <head>
        <title>'.$placeholder['category'].' Placeholder</title>
        <style>
            body, html {
                margin: 0;
                padding: 0;
                width: 100%;
                height: 100%;
                display: flex;
                align-items: center;
                justify-content: center;
                background-color: '.$placeholder['color'].';
                color: white;
                font-family: Arial, sans-serif;
                text-align: center;
            }
            .placeholder {
                width: 100%;
                max-width: '.$placeholder['width'].'px;
                height: '.$placeholder['height'].'px;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                border: 2px solid rgba(255,255,255,0.3);
            }
            h1 {
                margin: 0;
                padding: 10px;
                font-size: 24px;
            }
            p {
                margin: 10px 0 0 0;
                font-size: 16px;
            }
        </style>
    </head>
    <body>
        <div class="placeholder">
            <h1>Offset Printing - '.$placeholder['category'].'</h1>
            <p>'.$placeholder['width'].' x '.$placeholder['height'].' pixels</p>
        </div>
    </body>
    </html>';
    
    // Save the HTML placeholder
    file_put_contents($uploadDir . $placeholder['name'], $htmlContent);
}

// Sample product data to insert into the database
$sampleProducts = [
    [
        'name' => 'Premium Business Cards',
        'category' => 'Business Cards',
        'description' => 'High-quality business cards printed on 350gsm silk card with glossy finish.',
        'price' => 49.99,
        'stock' => 500,
        'image' => 'business_cards_placeholder.html'
    ],
    [
        'name' => 'A5 Promotional Flyers',
        'category' => 'Flyers',
        'description' => 'Full color A5 flyers printed on 170gsm gloss paper, perfect for marketing campaigns.',
        'price' => 79.99,
        'stock' => 1000,
        'image' => 'flyers_placeholder.html'
    ],
    [
        'name' => 'Tri-fold Brochures',
        'category' => 'Brochures',
        'description' => 'Professional tri-fold brochures printed on 150gsm art paper with matte lamination.',
        'price' => 129.99,
        'stock' => 250,
        'image' => 'brochures_placeholder.html'
    ],
    [
        'name' => 'A2 Promotional Posters',
        'category' => 'Posters',
        'description' => 'Eye-catching A2 posters printed on 190gsm photo paper, ideal for indoor display.',
        'price' => 149.99,
        'stock' => 100,
        'image' => 'posters_placeholder.html'
    ],
    [
        'name' => 'Vinyl Outdoor Banners',
        'category' => 'Banners',
        'description' => 'Weather-resistant vinyl banners with reinforced edges and grommets for outdoor use.',
        'price' => 199.99,
        'stock' => 50,
        'image' => 'banners_placeholder.html'
    ]
];

// Insert products
$productsAdded = 0;

foreach ($sampleProducts as $product) {
    // Check if product already exists
    $checkQuery = "SELECT id FROM products WHERE name = '{$product['name']}'";
    $existingProduct = getRecord($checkQuery);
    
    if (!$existingProduct) {
        // Insert product into database
        $insertQuery = "
        INSERT INTO products (name, category, description, price, stock, image) 
        VALUES (
            '{$product['name']}', 
            '{$product['category']}', 
            '{$product['description']}', 
            {$product['price']}, 
            {$product['stock']}, 
            '{$product['image']}'
        )";
        
        if (executeQuery($insertQuery)) {
            $productsAdded++;
        }
    }
}

// Output results
echo "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Sample Products Generated</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .success {
            color: green;
            font-weight: bold;
        }
        .gallery {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .image-card {
            border: 1px solid #ddd;
            padding: 10px;
            border-radius: 5px;
        }
        .image-card .placeholder {
            width: 100%;
            height: 150px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            text-align: center;
            margin-bottom: 10px;
        }
        .business-cards {
            background-color: #4287f5;
        }
        .flyers {
            background-color: #2ecc71;
        }
        .brochures {
            background-color: #e74c3c;
        }
        .posters {
            background-color: #f1c40f;
        }
        .banners {
            background-color: #9b59b6;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            background-color: #4e73df;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <h1>Sample Products for Offset Printing Management</h1>";

// Output results
echo "<p class='success'>Successfully created " . count($cssPlaceholders) . " placeholder files in the 'upload' directory.</p>";
echo "<p class='success'>Added $productsAdded new sample products to the database.</p>";

// Display gallery of sample products
echo "<h2>Sample Products</h2>";
echo "<div class='gallery'>";

// Get all products from database
$productsQuery = "SELECT * FROM products";
$products = getRecords($productsQuery);

if (!empty($products)) {
    foreach ($products as $product) {
        // Create CSS class name from category
        $cssClass = strtolower(str_replace(' ', '-', $product['category']));
        
        echo "<div class='image-card'>
            <h3>{$product['name']}</h3>
            <div class='placeholder {$cssClass}'>{$product['category']}</div>
            <p><strong>Category:</strong> {$product['category']}</p>
            <p><strong>Price:</strong> \${$product['price']}</p>
            <p><strong>Stock:</strong> {$product['stock']}</p>
        </div>";
    }
} else {
    echo "<p>No products found in the database.</p>";
}

echo "</div>";

echo "<div class='actions' style='margin-top: 20px;'>
    <a href='products.php' class='back-link'>Go to Product Management</a>
    <a href='dashboard.php' class='back-link' style='margin-left: 10px;'>Go to Dashboard</a>
</div>
</body>
</html>";
?>
