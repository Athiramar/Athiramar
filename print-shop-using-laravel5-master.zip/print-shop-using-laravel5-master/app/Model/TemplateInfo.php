<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 3/16/2017
 * Time: 12:26 AM
 */

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class TemplateInfo extends Model
{
    protected $table = 'template_info';
}