<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 4/3/2017
 * Time: 8:00 PM
 */
return  [
  'new'=>'new order',
  'prog-upload'=>'order in progress( upload for customer review )',
  'prog-review'=>'order in progress( review/edit )',
  'approved'=>'order approved from customer',
  'production'=>'order in production',
  'pick'=>'order is ready for pickup from store',
  'ship'=>'order in shipment',
  'completed'=>'order complete'
];