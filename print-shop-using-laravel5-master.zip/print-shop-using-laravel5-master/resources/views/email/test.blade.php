<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
    <meta charset="utf-8" />
    <title>Account Details | Ghoori</title>
</head>

<body>
<div style="margin:0;padding:0">
    <div class="adM"></div>
    <table bgcolor="#f1f1f1" width="100%" height="100%" align="center" style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0"  background="https://ghoori.com.bd/img/log_in_page.png">
        <tbody>
        <tr align="center">
            <td valign="top">
                <table bgcolor="#f1f1f1" height="60" style="border-collapse:collapse" border="0" cellspacing="0" cellpadding="0" width="45%">
                    <tbody>
                    <tr valign="middle" height="40">
                        <td width="9"></td>
                        <td width="217" valign="middle">
                            <img src="https://ghoori.com.bd/img/55_double.png" border="0" alt="Ghoori Accounts" style="display:block" height="40" class="CToWUd" />
                        </td>
                        <td width="327" style="font-size:13px;font-family:arial,sans-serif;color:#777777;text-align:right">
                            aSDF
                        </td>
                        <td width="10"></td>
                        <!-- <td>
                          <img src="images/name.jpg" width="27" height="27" class="CToWUd">
                        </td> -->
                        <td width="10"></td>
                    </tr>
                    </tbody>
                </table>
                <table border="0" style="border:1px solid #999999;padding:5px;text-align:left;" cellspacing="0" cellpadding="0" bgcolor="#ffffff" width="45%">
                    <tbody>
                    <tr>
                        <td height="15" style="border-top:none;border-bottom:none;border-left:none;border-right:none;"></td>
                    </tr>
                    <tr>
                        <td width="15" style="border-top:none;border-bottom:none;border-left:none;border-right:none"></td>
                        <td colspan="3" style="font-size:83%;border-top:none;border-bottom:none;border-left:none;border-right:none;font-size:13px;font-family:arial,sans-serif;color:#444444;line-height:18px;">
                            <br />
                            Dear BCF
                            <br />
                            <br />
                            Thanks for being with Ghoori. We are working to make our billing system automated and for that we need your cooperation. Please provide billing information below to us, so that we can disburse your payment on time and easily.
                            <br />
                            <br />
                            <br />
                            <strong>Bank account details:</strong>
                            <br />
                            <ul style="list-style:none;">
                                <li>Bank Name:</li>
                                <li>Branch Name:</li>
                                <li>A/C Holder Name:</li>
                                <li>Chose the discount amount</li>
                                <li>A/C Number:</li>
                            </ul>
                            Or
                            <br />
                            <br />
                            <strong>bKash account details:</strong>
                            <br />
                            <ul style="list-style:none;">
                                <li>bKash account owner name:</li>
                                <li>bKash Number:</li>
                            </ul>
                            <br />
                            Please send us the information within next 48 hours to avoid late disbursement. For any query please call us 09612-000888 or email us at info@ghoori.com.bd. If you want to know more about Ghoori billing cycle or disbursement policy click <a href="https://ghoori.com.bd/faq" style="text-decoration:none;color:#4d90fe" target="_blank"><b>here</b></a>.
                            <br />
                            <br />
                            <br />
                            Cheers,
                            <br />
                            Team Ghoori
                            <br />
                            Contact: 09612000888
                        </td>
                        <td width="15" style="border-top:none;border-bottom:none;border-left:none;border-right:none"></td>
                    </tr>
                    <tr>
                        <td height="15" style="border-top:none;border-bottom:none;border-left:none;border-right:none"></td>
                    </tr>
                    <tr>
                        <td width="15" style="border-top:none;border-bottom:none;border-left:none;border-right:none"></td>
                        <td style="font-size:11px;font-family:arial,sans-serif;color:#777777;border-top:none;border-bottom:none;border-left:none;border-right:none">
                        </td>
                        <td width="15" style="border-top:none;border-bottom:none;border-left:none;border-right:none"></td>
                        <td width="100" style="text-align:right;font-size:11px;font-family:arial,sans-serif;color:#777777;border-top:none;border-bottom:none;border-left:none;border-right:none">a <a href="https://chorki.com/" target="_blank"><img src="https://ghoori.com.bd/img/chorki-logo.png" alt="Chorki" width="30" height="20" /></a> product</td>
                        <td width="15" style="border-top:none;border-bottom:none;border-left:none;border-right:none"></td>
                    </tr>
                    </tbody>
                </table>
                <table border="0" bgcolor="#f1f1f1" height="60" style="text-align:left" width="45%">
                    <tbody>
                    <tr valign="middle">
                        <td style="font-size:11px;font-family:arial,sans-serif;color:#777777; text-align:center;">
                            You received this mandatory email service announcement to make you updated about <a href="https://ghoori.com.bd/faq" style="text-decoration:none;color:#4d90fe" target="_blank"><b>Ghoori</b></a>.
                            <br />
                            <br />
                            <div style="direction:ltr">
                                © 2015 Chorki Limited, Wakil Tower (Level 7), Gulshan-Badda Link Road, Dhaka, Bangladesh.
                            </div>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        </tbody>
    </table>
</div>

</body>

</html>