<script src="{{asset('js/library/jquery.min.js')}}"></script>
<!-- Bootstrap Core JavaScript -->
<script src="{{asset('js/library/owl.carousel.min.js')}}"></script>
<script src="{{asset('js/library/Chart.js')}}"></script>
<script src="{{asset('js/library/doughnutit.js')}}"></script>
<script src="{{asset('js/library/slideshow/jquery.themepunch.revolution.js')}}"></script>
<script src="{{asset('js/library/slideshow/jquery.themepunch.plugins.min.js')}}"></script>
<script src="{{asset('js/library/bootstrap-datepicker.min.js')}}"></script>
<script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.4/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/select/1.2.1/js/dataTables.select.min.js"></script>
<script src="{{asset('js/user-main.js')}}"></script>
<script src="{{asset('js/sweetalert.min.js')}}"></script>

<script src="{{asset('bootstrap/dist/js/bootstrap.min.js')}}"></script>

<script src="{{asset('js/custom.js')}}"></script>
@section('page-specific-js')
@show
