<link href='https://fonts.googleapis.com/css?family=Arimo:500,300,700,400' rel='stylesheet' type='text/css' />
<link href="{{asset('bootstrap/dist/css/bootstrap.min.css')}}" rel="stylesheet">
<link href="{{asset('css/library/font-awesome.min.css')}}" rel="stylesheet">
<link href="{{asset('css/library/owl.carousel.css')}}" rel="stylesheet">
<link href="{{asset('css/library/settings.css')}}" rel="stylesheet">
<link href="{{asset('css/library/jquery.jscrollpane.css')}}" rel="stylesheet">
<link href="{{asset('css/library/subscribe-better.css')}}" rel="stylesheet">
<link href="{{asset('css/library/owl.transitions.css')}}" rel="stylesheet">
<link href="{{asset('css/library/bootstrap-datepicker.min.css')}}" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css" >
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.2.4/css/buttons.dataTables.min.css" >
<link rel="stylesheet" href="https://cdn.datatables.net/select/1.2.1/css/select.dataTables.min.css" >
<link href="{{asset('css/user-main.css')}}" rel="stylesheet">
<link href="{{asset('css/library/newsletter.css')}}" rel="stylesheet">
<link href="{{asset('css/library/responsive.css')}}" rel="stylesheet">
<link href="{{asset('css/custom.css')}}" rel="stylesheet">
<link href="{{asset('css/sweetalert.css')}}" rel="stylesheet">
<link href="{{asset('css/user-custom.css')}}" rel="stylesheet">
@section('page-specific-css')
@show
