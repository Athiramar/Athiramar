<!-- jQuery -->
<script src="{{asset('js/library/jquery.min.js')}}"></script>
<!-- Bootstrap Core JavaScript -->
<script src="{{asset('bootstrap/dist/js/bootstrap.min.js')}}"></script>
<!-- Menu Plugin JavaScript -->
<script src="{{asset('js/library/sidebar-nav.min.js')}}"></script>
<!--slimscroll JavaScript -->
<script src="{{asset('js/library/jquery.slimscroll.js')}}"></script>
<!--Wave Effects -->
<script src="{{asset('js/library/waves.js')}}"></script>
<!-- Datatable -->
<script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.4/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/select/1.2.1/js/dataTables.select.min.js"></script>
<!-- Custom Theme JavaScript -->
<script src="{{asset('js/admin.min.js')}}"></script>
<script src="{{asset('js/sweetalert.min.js')}}"></script>

<script src="{{asset('js/library/jquery.sparkline.min.js')}}"></script>

@section('page-specific-js')

@show