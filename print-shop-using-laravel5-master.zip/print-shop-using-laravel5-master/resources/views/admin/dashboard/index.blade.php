@extends('admin.template.layout')
@section('title')
    Dashboard | Admin
@stop
@section('page-specific-css')
@stop
@section('content')

@stop