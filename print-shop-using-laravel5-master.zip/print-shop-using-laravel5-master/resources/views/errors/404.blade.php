@extends('user.template.layout')
@section('title')
    Home
@stop
@section('page-specific-css')
@stop
@section('content')

    <section class="account-content parten-bg">
        <div class="container">
            <!--Account top banner -->
            <div class="row">
                    <a href="#" title="cart top banner">
                        <img src="{{asset('images/404.jpg')}}" alt="Cart top banner" />
                    </a>
            </div><!--Account top banner : End-->
        </div>
    </section>

@stop
