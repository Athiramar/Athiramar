# print-shop-using-laravel5
This is POC project using Laravel 5, Bootstrat and JQuery. `php >= 5.6.4` and `laravel >= 5.3`

run `php artisan make:migration` for migrating the tables into database. NB create a database named ecommerce.

use `php artisan serve` to serve the application on port 8000

## Admin Panel

goto `/admin` to enter the admin panel.

## Super Admin Panel

goto `/admin` and use the `username` and `password` of `superadmin` to enter the super admin panel.