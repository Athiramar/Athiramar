<?php
session_start();
$_SESSION['cart'] = array(); // Clear the cart
header("Location: cart.php");
exit();
?>
// flyers

<?php
session_start();
$_SESSION['cart'] = [];
header("Location: cart.php");
exit();
?>
