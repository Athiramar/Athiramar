<!-- navbar.php -->
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>

<nav>
    <ul>
        <li><a href="business_cards.php">Business Cards</a></li>
        <li><a href="flyers.php">Flyers</a></li>
        <li><a href="posters.php">Posters</a></li>
        <li><a href="food_packaging.php">Food Packaging</a></li>
        <li><a href="magazines.php">Magazines</a></li>
        <li><a href="cart.php">View Cart</a></li>
    </ul>
</nav>

</body>
</html>
