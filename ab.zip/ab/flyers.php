<?php
session_start();
include 'navbar.php';

if (!isset($_SESSION['cartfly'])) {
    $_SESSION['cartfly'] = [];
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_to_cart'])) {
    $product = [
        "id" => $_POST['id'],
        "name" => $_POST['name'],
        "price" => 500,
        "quantity" => $_POST['quantity']
    ];

    $_SESSION['cartfly'][] = $product;
    header("Location: cartfly.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flyers - Digital Printing</title>
    <link rel="stylesheet" type="text/css" href="stylefly.css">
</head>
<body>

<h2>Flyers</h2>

<div class="product-container">
    <?php
    $flyers = [
        ["id" => 1, "name" => "Business Promotion Flyer", "image" => "images/flyer1.jpg"],
        ["id" => 2, "name" => "Real Estate Flyer", "image" => "images/flyer2.jpg"],
        ["id" => 3, "name" => "Restaurant Menu Flyer", "image" => "images/flyer3.jpg"],
        ["id" => 4, "name" => "Event Invitation Flyer", "image" => "images/flyer4.jpg"],
        ["id" => 5, "name" => "Corporate Flyer", "image" => "images/flyer5.jpg"]
    ];

    foreach ($flyers as $flyer) {
        echo "<div class='product'>";
        echo "<img src='{$flyer['image']}' alt='{$flyer['name']}' class='product-img'>";
        echo "<h3>{$flyer['name']}</h3>";
        echo "<p>Price: ₹500</p>";
        echo "<form method='POST' action='flyers.php'>";
        echo "<input type='hidden' name='id' value='{$flyer['id']}'>";
        echo "<input type='hidden' name='name' value='{$flyer['name']}'>";
        echo "Quantity: <input type='number' name='quantity' value='1' min='1'>";
        echo "<button type='submit' name='add_to_cart'>Add to Cart</button>";
        echo "</form>";
        echo "</div>";
    }
    ?>
</div>

</body>
</html>
