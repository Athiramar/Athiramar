<?php
session_start();
include 'navbar.php';

// Sample poster products
$posters = [
    ["id" => 1, "name" => "Abstract Poster", "price" => 500, "image" => "images/poster1.jpg"],
    ["id" => 2, "name" => "Nature Poster", "price" => 500, "image" => "images/poster2.jpg"],
    ["id" => 3, "name" => "Vintage Poster", "price" => 500, "image" => "images/poster3.jpg"],
    ["id" => 4, "name" => "Modern Art Poster", "price" => 500, "image" => "images/poster4.jpg"],
    ["id" => 5, "name" => "Typography Poster", "price" => 500, "image" => "images/poster5.jpg"]
];

// Handle adding to cart
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $posterId = $_POST['poster_id'];
    foreach ($posters as $poster) {
        if ($poster['id'] == $posterId) {
            $_SESSION['cart'][] = $poster;
            break;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Posters</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>

<h2>Posters</h2>
<div class="product-container">
    <?php foreach ($posters as $poster) : ?>
        <div class="product">
            <img src="<?= $poster['image']; ?>" alt="<?= $poster['name']; ?>">
            <h3><?= $poster['name']; ?></h3>
            <p>Price: ₹<?= $poster['price']; ?></p>
            <form method="POST">
                <input type="hidden" name="poster_id" value="<?= $poster['id']; ?>">
                <button type="submit">Add to Cart</button>
            </form>
        </div>
    <?php endforeach; ?>
</div>

<a href="cart.php">View Cart</a>

</body>
</html>

