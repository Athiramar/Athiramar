<?php
session_start();
$host = "127.0.0.1";
$username = "root";
$password = "root";
$database = "products";

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

function sanitize_input($data) {
    global $conn;
    return mysqli_real_escape_string($conn, trim($data));
}

// Handle add to cart
if (isset($_POST['add_to_cart'])) {
    $product_id = sanitize_input($_POST['product_id']);
    $product_name = sanitize_input($_POST['product_name']);

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }

    $_SESSION['cart'][] = array(
        'product_id' => $product_id,
        'product_name' => $product_name,
        'category' => 'Business Cards',
        'quantity' => 1,
        'price' => 500
    );

    header("Location: business_cards.php");
    exit();
}

// Business Cards Data
$products = array(
    array('id' => 1, 'name' => 'Elegant Business Card', 'image' => 'images/business_cards/bc1.jpg', 'description' => 'Sleek and modern design.'),
    array('id' => 2, 'name' => 'Classic Business Card', 'image' => 'images/business_cards/bc2.jpg', 'description' => 'Professional and timeless.'),
    array('id' => 3, 'name' => 'Minimalist Business Card', 'image' => 'images/business_cards/bc3.jpg', 'description' => 'Clean and simple.'),
    array('id' => 4, 'name' => 'Creative Business Card', 'image' => 'images/business_cards/bc4.jpg', 'description' => 'Unique and eye-catching.'),
    array('id' => 5, 'name' => 'Luxury Business Card', 'image' => 'images/business_cards/bc5.jpg', 'description' => 'High-end and sophisticated.')
);
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <title>Business Cards</title>
</head>
<body>

<?php include 'navbar.php'; ?>

<h1>Business Cards</h1>
    <link rel="stylesheet" type="text/css" href="styless.css">


<div class="product-container">
    <?php foreach ($products as $product): ?>
        <div class="product">
            <img src="<?= $product['image'] ?>" alt="<?= $product['name'] ?>">
            <p><?= $product['name'] ?></p>
            <p><?= $product['description'] ?></p>
            <p>Price: ₹500</p>
            <form method="post">
                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                <input type="hidden" name="product_name" value="<?= $product['name'] ?>">
                <button type="submit" name="add_to_cart">Add to Cart</button>
            </form>
        </div>
    <?php endforeach; ?>
</div>

</body>
</html>

<?php mysqli_close($conn); ?>
